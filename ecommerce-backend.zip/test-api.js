const axios = require("axios");

const BASE_URL = "http://localhost:3000/api";

async function testAPI() {
  try {
    console.log("🟢 Testing API endpoints...\n");

    let res = await axios.get(`${BASE_URL}/health`);
    console.log("Health:", res.data);

    res = await axios.get(`${BASE_URL}/products`);
    console.log("Products:", res.data);

    res = await axios.get(`${BASE_URL}/products/1`);
    console.log("Product by ID:", res.data);

    res = await axios.get(`${BASE_URL}/categories`);
    console.log("Categories:", res.data);

    console.log("\n✅ All manual API tests passed!");
  } catch (err) {
    console.error("❌ Error:", err.message);
  }
}

testAPI();