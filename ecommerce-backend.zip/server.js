const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// Sample products
const products = [
  { id: 1, name: "iPhone 15 Pro", description: "Apple flagship phone", price: 999, stock: 10, category: "Electronics", images: ["iphone.jpg"] },
  { id: 2, name: "MacBook Air M2", description: "Lightweight laptop", price: 1299, stock: 5, category: "Electronics", images: ["macbook.jpg"] },
  { id: 3, name: "Nike Air Max 270", description: "Running shoes", price: 150, stock: 20, category: "Footwear", images: ["nike.jpg"] },
  { id: 4, name: "Samsung 4K Smart TV", description: "Smart television", price: 800, stock: 8, category: "Electronics", images: ["samsung.jpg"] },
  { id: 5, name: "Adidas Ultraboost 22", description: "Comfort running shoes", price: 180, stock: 15, category: "Footwear", images: ["adidas.jpg"] }
];

// Health check
app.get("/api/health", (req, res) => {
  res.json({ success: true, message: "Server is healthy" });
});

// Get all products with optional filters
app.get("/api/products", (req, res) => {
  let filtered = [...products];
  const { search, category, minPrice, maxPrice, availability } = req.query;

  if (search) {
    filtered = filtered.filter(
      (p) =>
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.description.toLowerCase().includes(search.toLowerCase())
    );
  }
  if (category) {
    filtered = filtered.filter((p) => p.category.toLowerCase() === category.toLowerCase());
  }
  if (minPrice) {
    filtered = filtered.filter((p) => p.price >= parseFloat(minPrice));
  }
  if (maxPrice) {
    filtered = filtered.filter((p) => p.price <= parseFloat(maxPrice));
  }
  if (availability === "inStock") {
    filtered = filtered.filter((p) => p.stock > 0);
  }
  if (availability === "outOfStock") {
    filtered = filtered.filter((p) => p.stock === 0);
  }

  res.json({ success: true, total: filtered.length, data: filtered, message: "Products retrieved successfully" });
});

// Get product by ID
app.get("/api/products/:id", (req, res) => {
  const product = products.find((p) => p.id == req.params.id);
  if (!product) {
    return res.status(404).json({ success: false, message: "Product not found" });
  }
  res.json({ success: true, data: product });
});

// Get products by category
app.get("/api/products/category/:category", (req, res) => {
  const category = req.params.category.toLowerCase();
  const filtered = products.filter((p) => p.category.toLowerCase() === category);
  res.json({ success: true, total: filtered.length, data: filtered });
});

// Search products
app.get("/api/products/search/:query", (req, res) => {
  const query = req.params.query.toLowerCase();
  const filtered = products.filter(
    (p) =>
      p.name.toLowerCase().includes(query) ||
      p.description.toLowerCase().includes(query) ||
      p.category.toLowerCase().includes(query)
  );
  res.json({ success: true, total: filtered.length, data: filtered });
});

// Get all categories
app.get("/api/categories", (req, res) => {
  const categories = [...new Set(products.map((p) => p.category))];
  res.json({ success: true, total: categories.length, data: categories });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
});

module.exports = app; // for testing